export declare const COLORS: Array<(s: string) => string>;
export default function colorize(line: string): string;
