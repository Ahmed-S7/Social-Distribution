export declare function revertSortedArgs(processArgs: Array<string>, argv: Array<string>): string[];
export declare function buildCommand(args: Array<string>, prependLauncher?: boolean): string;
export declare function buildEnvFromFlag(flag: string): {};
