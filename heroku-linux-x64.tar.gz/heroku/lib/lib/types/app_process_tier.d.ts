import { App } from './fir';
export interface AppProcessTier extends App {
    process_tier: string;
}
