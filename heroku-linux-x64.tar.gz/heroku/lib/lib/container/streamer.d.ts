export declare const streamer: (url: string, out: NodeJS.WriteStream) => Promise<unknown>;
