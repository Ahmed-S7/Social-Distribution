export default function keyBy(list: any, propertyOrCb: any): any;
