import { Hook } from '@oclif/core';
declare const analytics: Hook<'prerun'>;
export default analytics;
