import { Hook } from '@oclif/core';
declare const performance_analytics: Hook<'postrun'>;
export default performance_analytics;
