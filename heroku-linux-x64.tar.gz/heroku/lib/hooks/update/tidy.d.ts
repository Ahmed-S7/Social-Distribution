import { Hook } from '@oclif/core';
declare const tidy: Hook<'update'>;
export default tidy;
